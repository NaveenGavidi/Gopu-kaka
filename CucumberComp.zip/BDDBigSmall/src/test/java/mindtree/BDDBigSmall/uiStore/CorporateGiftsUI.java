package mindtree.BDDBigSmall.uiStore;

import org.openqa.selenium.By;

public class CorporateGiftsUI {

	public static By clickCorporateGifts = By.xpath("//a[@class='site-nav__link']");
	public static By fillName = By.xpath("//input[@id='contactFormName']");
	public static By fillEmail = By.xpath("//input[@id='contactFormEmail']");
	public static By fillPhoneNo = By.xpath("//input[@id='contactFormPhone']");
	public static By fillInquiry = By.xpath("//textarea[@id='contactFormMessage']");
	public static By clcikSubmit = By.xpath("//input[@class='btn']");
}
