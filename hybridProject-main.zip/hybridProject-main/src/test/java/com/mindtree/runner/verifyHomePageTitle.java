package com.mindtree.runner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.mindtree.reusablecomponent.Base;


public class verifyHomePageTitle extends Base {
	
	public static Logger log=LogManager.getLogger(verifyHomePageTitle.class.getName());
	
	@BeforeMethod
	public void OpenBrowser() throws Exception
	{
		 driver=initializeDriver();		 
	}
	
	@Test
	public void verifyTitle() throws Exception
	{
		test.info("Browser Opened");
		log.info("Browser Opened");
		driver.get(property.getUrl());
		log.info("Navigate to Url : "+driver.getCurrentUrl());
		test.info("Navigate to Url "+driver.getCurrentUrl());
		test.info("validating Title");
		Assert.assertEquals(driver.getTitle(),"Gifts Online - Send Unique, Unusual Gifts in India, Buy Gifts– Bigsmall.in");
		log.info("Title Validating Passed");
		test.pass("Title Matched");
	}
	

}
